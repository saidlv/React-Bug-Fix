import "./App.css";
import React, { useState } from "react";
import "react-pro-sidebar/dist/css/styles.css";
import { ProSidebar, Menu } from "react-pro-sidebar";

function App() {
  const [open, setOpen] = useState("home");
  const [drawer, setDrawer] = useState(false);

  return (
    <>
      {drawer && (
        <ProSidebar
          style={{
            top: 0,
            left: 0,
            overflow: "hidden",
            position: "absolute",
            boxShadow: "0 0 1px gray",
            borderRight: "1px solid gainsboro",
          }}
          coÏllapsed={true}
          collapsedWidth={"0px"}
        >
          <Menu
            style={{
              top: 0,
              left: 0,
              width: "100%",
              height: "90vh",
              paddingTop: "3em",
              overflow: "hidden",
              position: "absolute",
              backgroundColor: "white",
            }}
          >
            <img
              class="crossImg"
              src="./images/cross.svg"
              onClick={() => setDrawer(!drawer)}
            />
            <img
              class="drawerImg"
              src="./images/contact.png"
              onClick={() => setOpen("contact")}
            />
            <img
              class="drawerImg"
              src="./images/distance.png"
              onClick={() => setOpen("distance")}
            />
            <img
              class="drawerImg"
              src="./images/projects.png"
              onClick={() => setOpen("projects")}
            />
            <img
              class="drawerImg"
              src="./images/shop.png"
              onClick={() => setOpen("shop")}
            />
            <img
              class="drawerImg"
              src="./images/consult.png"
              onClick={() => setOpen("consult")}
            />
            <img
              class="drawerImg"
              src="./images/members.png"
              onClick={() => setOpen("members")}
            />
            <img
              class="drawerImg"
              src="./images/bio.png"
              onClick={() => setOpen("bio")}
            />
          </Menu>
        </ProSidebar>
      )}
      <div className="nav">
        <img
          class="drawerImg"
          src="./images/bars.svg"
          onClick={() => setDrawer(!drawer)}
        />
      </div>
      <div id="mainBox">
        <img
          class="contactImg"
          src="./images/contact.png"
          onClick={() => setOpen("contact")}
        />
        <div class="main">
          <div class="originally">
            <img
              class="optionsImg"
              src="./images/distance.png"
              id="mainLogo"
              onClick={() => setOpen("distance")}
            />
          </div>
          {open === "home" && <img src="./images/logo.jpeg" class="mainImg" />}
          {open === "bio" && (
            <p class="bioPara">
              "Duane Gordon's journey to answer the question “Who am I?” mines
              the distinctly urban landscape and social injustices he
              experienced growing up in Southwest Philadelphia. A self-defined
              entrepreneur/artist, Duane Gordon Jr. began his career by hiring
              artists to produce his custom shirts. He soon realized that he
              wanted to express his own creativity, and started painting and
              designing under the name “Originally Distinct.” His unflinching
              search to illuminate the forces shaping his life and city gives
              voice to the individuality of those who collect and wear his work.
              The direct questions and catch phrases he uses are integral to his
              imagery, and a signature element of his “lifestyle brand.” Duane
              aims to keep growing as an artist, to inspire others to embrace
              their unique and original selves, and to light a path for emerging
              artists to become truly self-sufficient. This creative loop feeds
              Duane’s passion for fusing his expanding enterprise with ever more
              ambitious and personal art. Mr. Gordon works in a wide range of
              mediums, from acrylics on canvas and ink on paper to painting
              directly on found objects such as street signs. He loves creating
              rich surfaces which catch the eye with subtle yet luminous
              highlights, and is deeply grateful for the collective of talents
              who manufacture his limited-edition fashions, jewelry and home
              accessories. Duane Gordon’s work has been exhibited at the A+D
              Museum in Los Angeles (August 2020), featured on ABC’s FYI Philly
              (April 2019) and in Voyage Atlanta (July 2020), presented at
              Trunc, a Northern Liberties artisan boutique for handmade art
              (2019-20), exhibited in a private show at 1635 Market Street
              (December 2019), Did a special release for his OD1 High sneaker at
              Joan Shepp (April 2021) and painted a mural in Old City - 239
              Chestnut St. (April 2021). Currently, he is preparing to launch
              his “Originally Distinct” showroom and gallery in Old City.
            </p>
          )}
          {open === "shop" && (
            <div className="box">
              <p>Shop</p>
            </div>
          )}
          {open === "members" && (
            <div className="box">
              <p>Members</p>
            </div>
          )}
          {open === "consult" && (
            <div className="box">
              <p>Consult</p>
            </div>
          )}
          {open === "contact" && (
            <div className="box">
              <p>Contact</p>
            </div>
          )}
          {open === "distance" && (
            <div className="box">
              <p>Distance</p>
            </div>
          )}
          {open === "projects" && (
            <div className="box">
              <p>Projects</p>
            </div>
          )}
          <div class="options">
            <img
              class="optionsImg"
              src="./images/projects.png"
              onClick={() => setOpen("projects")}
            />
            <img
              class="optionsImg"
              src="./images/shop.png"
              onClick={() => setOpen("shop")}
            />
            <img
              class="optionsImg"
              src="./images/consult.png"
              onClick={() => setOpen("consult")}
            />
            <img
              class="optionsImg"
              src="./images/members.png"
              onClick={() => setOpen("members")}
            />
            <img
              class="optionsImg"
              src="./images/bio.png"
              onClick={() => setOpen("bio")}
            />
          </div>
        </div>
      </div>
      {/* this box is for mobile  */}
    </>
  );
}

export default App;
